/*
 * apop.c Copyright (c) 1996 by Bert Gijsbers (bert@mc.bio.uva.nl).
 * GNU General Public License version 2 applies.
 */

#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <fcntl.h>
#include <errno.h>
#include <termios.h>
#include <pwd.h>
#include <sys/stat.h>

#include "conf-apop.h"

static char apop_user[] = APOP_USERNAME;
static char apop_db[] = APOP_DB_PATH;

static void usage()
{
    fprintf(stderr,
"Usage: apop [ -i | -u name | -m mailbox | -d mailbox | -p mailbox ]\n");
    exit(1);
}

static void init_apop_perms()
{
    struct passwd *pwd;

    if (!(pwd = getpwnam(apop_user))) {
	fprintf(stderr, "Error: Cannot find /etc/passwd entry for %s\n", apop_user);
	exit(1);
    }
    setgid(pwd->pw_gid);
    setuid(pwd->pw_uid);
    if (geteuid() != pwd->pw_uid) {
	perror("Error: Cannot change to apop user ID");
	exit(1);
    }
}

static void make_apop_dir(path)
    char *path;
{
    struct passwd *pwd;
    struct stat st;

    if (!(pwd = getpwnam(apop_user))) {
	fprintf(stderr, "Error: Cannot find /etc/passwd entry for %s\n", apop_user);
	exit(1);
    }
    if (stat(path, &st)) {
	if (mkdir(path, 0700)) {
	    perror(path);
	    exit(1);
	}
    }
    else {
	if ((st.st_mode & S_IFMT) != S_IFDIR) {
	    fprintf(stderr, "Error: %s is not a directory\n", path);
	    exit(1);
	}
	if (chmod(path, 0700)) {
	    perror("Error: Cannot chmod directory");
	    exit(1);
	}
    }
    if (chown(path, pwd->pw_uid, pwd->pw_gid)) {
	perror("Error: Cannot chown directory");
	exit(1);
    }
}

static int init_database()
{
    if (setuid(getuid())) {
	perror("Error: Cannot change user ID");
	exit(1);
    }
    umask(077);

    make_apop_dir(apop_db);
    if (chdir(apop_db)) {
	perror("Error: Cannot change current directory to apop directory");
	exit(1);
    }
    make_apop_dir("pwd");
    make_apop_dir("box");
    make_apop_dir("tmp");

    return 0;
}

static void clean_filename(file)
    char *file;
{
    char *str;

    for (str = file; *str; str++) {
	if (*str == '.') {
	    *str = ':';
	}
    }
}

static void get_passphrase(prompt, phrase, maxlen)
    char *prompt;
    char *phrase;
    unsigned maxlen;
{
    int fd, len, i;
    struct termios term;

    if ((fd = open("/dev/tty", O_RDWR)) == -1) {
	fd = 0;
    }
    memset(&term, 0, sizeof term);
    if (tcgetattr(fd, &term) == 0) {
	if ((term.c_lflag & ECHO) != 0) {
	    term.c_lflag &= ~ECHO;
	    tcsetattr(fd, TCSAFLUSH, &term);
	    term.c_lflag |= ECHO;
	}
    }
    printf(prompt);
    fflush(stdout);
    len = read(fd, phrase, maxlen);
    if ((term.c_lflag & ECHO) != 0) {
	tcsetattr(fd, TCSAFLUSH, &term);
    }
    if (fd != 0) {
	close(fd);
    }
    printf("\n");
    fflush(stdout);

    if (len <= 0 || phrase[len - 1] != '\n') {
	perror("Error reading passphrase");
	exit(1);
    }
    for (i = 0; i < len; i++) {
	if (phrase[i] == '\n' || phrase[i] == '\r') {
	    phrase[i] = '\0';
	    len = i;
	    break;
	}
	/* Assume ASCII. */
	if (phrase[i] < ' ') {
	    fprintf(stderr, "Error: The passphrase should not contain any control characters\n");
	    exit(1);
	}
	if (phrase[i] > '~') {
	    fprintf(stderr, "Error: The passphrase may only contain 7-bit USASCII characters\n");
	    exit(1);
	}
    }
    if (len < 8) {
	fprintf(stderr, "Error: The passphrase must have at least 8 characters\n");
	exit(1);
    }
}

static void write_passphrase(phrase, path)
    char *phrase;
    char *path;
{
    int fd;

    unlink(path);
    if ((fd = open(path, O_RDWR | O_CREAT | O_TRUNC, 0600)) == -1) {
	perror("Error: Cannot create database entry");
	exit(1);
    }
    if (write(fd, phrase, strlen(phrase)) != strlen(phrase)) {
	perror("Error: Cannot write database entry");
	unlink(path);
	exit(1);
    }
    if (fsync(fd) == -1) {
	perror("Error: Cannot fsync database entry");
	unlink(path);
	exit(1);
    }
    close(fd);
}

static int add_user(username)
    char *username;
{
    char *use_path = 0;
    char file[1024];
    char pwd_path[1024];
    char box_path[1024];
    char tmp_path[1024];
    char phrase[1024];
    char phrase2[1024];
    struct stat st;

    if (getpwnam(username) == 0) {
	fprintf(stderr, "Error: Cannot find /etc/passwd entry for %s\n", username);
	exit(1);
    }

    init_apop_perms();

    if (chdir(apop_db)) {
	perror(apop_db);
	exit(1);
    }
    strcpy(file, username);
    clean_filename(file);

    sprintf(pwd_path, "pwd/%s", file);
    sprintf(box_path, "box/%s", file);
    sprintf(tmp_path, "tmp/%s", file);
    if (stat(pwd_path, &st) == 0 || stat(box_path, &st) == 0) {
	fprintf(stderr, "Error: There is already an apop database entry for %s\n", username);
	exit(1);
    }
    use_path = pwd_path;

    get_passphrase("Please enter the new passphrase: ", phrase, sizeof phrase);
    get_passphrase("Please reenter this passphrase: ", phrase2, sizeof phrase2);
    if (strcmp(phrase, phrase2)) {
	fprintf(stderr, "Error: Passphrases don't match\n");
	exit(1);
    }
    write_passphrase(phrase, tmp_path);

    if (rename(tmp_path, use_path)) {
	perror("Error: Cannot rename temporary database entry");
	unlink(tmp_path);
	exit(1);
    }

    return 0;
}

static int add_mailbox(mailbox)
    char *mailbox;
{
    char *use_path = 0;
    char file[1024];
    char pwd_path[1024];
    char box_path[1024];
    char tmp_path[1024];
    char phrase[1024];
    char phrase2[1024];
    struct stat st;

    init_apop_perms();

    if (chdir(apop_db)) {
	perror(apop_db);
	exit(1);
    }
    strcpy(file, mailbox);
    clean_filename(file);

    sprintf(pwd_path, "pwd/%s", file);
    sprintf(box_path, "box/%s", file);
    sprintf(tmp_path, "tmp/%s", file);
    if (stat(pwd_path, &st) == 0 || stat(box_path, &st) == 0) {
	fprintf(stderr, "Error: There is already an apop database entry for %s\n", mailbox);
	exit(1);
    }
    use_path = box_path;

    get_passphrase("Please enter the new passphrase: ", phrase, sizeof phrase);
    get_passphrase("Please reenter this passphrase: ", phrase2, sizeof phrase2);
    if (strcmp(phrase, phrase2)) {
	fprintf(stderr, "Error: Passphrases don't match\n");
	exit(1);
    }
    write_passphrase(phrase, tmp_path);

    if (rename(tmp_path, use_path)) {
	perror("Error: Cannot rename temporary database entry");
	unlink(tmp_path);
	exit(1);
    }

    return 0;
}

static int del_mailbox(mailbox)
    char *mailbox;
{
    char file[1024];
    char pwd_path[1024];
    char box_path[1024];
    struct stat st;
    int found = 0;

    init_apop_perms();

    if (chdir(apop_db)) {
	perror(apop_db);
	exit(1);
    }
    strcpy(file, mailbox);
    clean_filename(file);

    sprintf(pwd_path, "tmp/%s", file);
    sprintf(box_path, "box/%s", file);
    if (stat(pwd_path, &st) == 0) {
	found++;
	if (unlink(pwd_path)) {
	    perror(pwd_path);
	    exit(1);
	}
    }
    if (stat(box_path, &st) == 0) {
	found++;
	if (unlink(box_path)) {
	    perror(box_path);
	    exit(1);
	}
    }
    if (found == 0) {
	fprintf(stderr, "Error: Could not find database entry for %s\n", mailbox);
	exit(1);
    }

    return 0;
}

static int change_passphrase(mailbox)
    char *mailbox;
{
    int n;
    char *use_path = 0;
    char file[1024];
    char pwd_path[1024];
    char box_path[1024];
    char tmp_path[1024];
    char phrase[1024];
    char phrase2[1024];
    struct stat st;

    init_apop_perms();

    if (chdir(apop_db)) {
	perror(apop_db);
	exit(1);
    }
    strcpy(file, mailbox);
    clean_filename(file);

    sprintf(pwd_path, "pwd/%s", file);
    sprintf(box_path, "box/%s", file);
    sprintf(tmp_path, "tmp/%s", file);
    n = 0;
    if (stat(pwd_path, &st) == 0) {
	use_path = pwd_path;
	n++;
    }
    if (stat(box_path, &st) == 0) {
	use_path = box_path;
	n++;
    }
    if (n == 0) {
#if 0
	/* forbid user to initialise his own entry. */
	fprintf(stderr, "Error: mailbox %s has no apop database entry\n", mailbox);
	exit(1);
#else
	/* allow user to initialise his own entry. */
	/* maybe check password first? */
	use_path = pwd_path;
	printf("Initialising passphrase for mailbox \"%s\"\n", mailbox);
#endif
    }
    else if (n == 1) {
	printf("Changing passphrase for mailbox \"%s\"\n", mailbox);
    }
    else {
	fprintf(stderr, "Error: mailbox %s more than one database entry\n", mailbox);
	exit(1);
    }

    get_passphrase("Please enter the new passphrase: ", phrase, sizeof phrase);
    get_passphrase("Please reenter this passphrase: ", phrase2, sizeof phrase2);
    if (strcmp(phrase, phrase2)) {
	fprintf(stderr, "Error: Passphrases don't match\n");
	exit(1);
    }
    write_passphrase(phrase, tmp_path);

    if (n > 0 && unlink(use_path)) {
	perror("Error: Cannot unlink database entry");
	unlink(tmp_path);
	exit(1);
    }
    if (rename(tmp_path, use_path)) {
	perror("Error: Cannot rename temporary database entry");
	unlink(tmp_path);
	exit(1);
    }

    return 0;
}

static int do_options(argc, argv)
    int argc;
    char **argv;
{
    int c;

    if (getuid() != 0) {
	fprintf(stderr, "Error: Only the superuser is allowed to do this\n");
	return 1;
    }

    while ((c = getopt(argc, argv, "iu:m:d:p:")) != -1) {
	switch (c) {
	case 'i':
	    init_database();
	    break;
	case 'u':
	    add_user(optarg);
	    break;
	case 'm':
	    add_mailbox(optarg);
	    break;
	case 'd':
	    del_mailbox(optarg);
	    break;
	case 'p':
	    change_passphrase(optarg);
	    break;
	default:
	    usage();
	}
    }

    return 0;
}

static int do_default()
{
    char name[1024];
    struct passwd *pwd = getpwuid(getuid());
    if (pwd == 0) {
	fprintf(stderr, "Error: Cannot get your /etc/passwd entry\n");
	exit(1);
    }
    strcpy(name, pwd->pw_name);
    return change_passphrase(name);
}

int main(argc, argv)
    int argc;
    char **argv;
{
    if (argc > 1) {
	return do_options(argc, argv);
    } else {
	return do_default();
    }
}

