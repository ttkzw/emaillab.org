/*
 * apopauth.c copyright (C) 1996 by Bert Gijsbers (bert@mc.bio.uva.nl).
 * GNU Library General Public License version 2 applies.
 *
 * int apop_auth(char *loginname, char *passphrase, char *timestamp)
 * to perform APOP authorisation (see rfc 1725).
 * Return value is zero on failure, one on success if normal user account,
 * two on success if loginname refers to a mailbox-only pop-account.
 *
 * int has_apop(char *loginname) checks if there is an APOP database entry
 * for `name'.  It returns 1 or 2 if there is an APOP database entry for `name',
 * 0 if no such entry exists, and -1 on errors.
 */

#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <pwd.h>
#include <errno.h>
extern int errno;

/* configuration file */
#include "conf-apop.h"

/* MD5 library from ftp://ftp.cert.org/pub/tools/md5/ */
#include "global.h"
#include "md5.h"

/* replace dots in a filename with colons. */
static void clean_filename(file)
    char *file;
{
    char *str;

    for (str = file; *str; str++) {
	if (*str == '.') {
	    *str = ':';
	}
    }
}

static int get_apop_phrase(name, phrase, maxlen)
    char *name;
    char *phrase;
    int maxlen;
{
    int i, len, pwdfd, boxfd, result, fd;
    char path[1024];
    static char apop_db[] = APOP_DB_PATH;

    result = -1;
    fd = -1;

    if (!name || !name[0] || name[0] == '/') {
	return -1;
    }
    if (strlen(apop_db) + strlen(name) + 6 >= maxlen) {
	return -1;
    }

    strcpy(path, apop_db);
    strcat(path, "/pwd/");
    len = strlen(path);
    strcpy(path + len, name);
    clean_filename(path + len);
    errno = 0;
    pwdfd = open(path, O_RDONLY);
    if (pwdfd == -1) {
	if (errno != ENOENT) {
	    return -1;
	}
    }

    strcpy(path, apop_db);
    strcat(path, "/box/");
    len = strlen(path);
    strcpy(path + len, name);
    clean_filename(path + len);
    errno = 0;
    boxfd = open(path, O_RDONLY);
    if (boxfd == -1) {
	if (errno != ENOENT) {
	    return -1;
	}
	if (pwdfd == -1) {
	    /* there is no apop db entry for name. */
	    return 0;
	}
	/* it's a normal password account. */
	result = 1;
	fd = pwdfd;
    }
    else if (pwdfd != -1) {
	/* can't have two entries. */
	close(pwdfd);
	close(boxfd);
	return -1;
    }
    else {
	/* it's a pop-only non-account. */
	result = 2;
	fd = boxfd;
    }

    len = read(fd, phrase, maxlen);
    close(fd);
    if (len <= 0 || len >= maxlen) {
	return -1;
    }
    for (i = 0; i < len; i++) {
	if (phrase[i] == '\0' || phrase[i] == '\n' || phrase[i] == '\r') {
	    len = i;
	    break;
	}
    }
    phrase[len] = '\0';
    if (!len) {
	return -1;
    }

    return result;
}

int has_apop(name)
    char *name;
{
    int result;
    char phrase[1024];

    result = get_apop_phrase(name, phrase, (int) sizeof(phrase));
    memset(phrase, 0, sizeof(phrase));
    return result;
}

int apop_auth(name, hash, stamp)
    char *name;
    char *hash;
    char *stamp;
{
    int i;
    int db_result;
    MD5_CTX context;
    unsigned char digest[16];
    char phrase[1024];
    static char hex[] = "0123456789abcdef";

    if (!name || !name[0]) {
	return 0;
    }
    if (!hash || strlen(hash) != 32) {
	return 0;
    }
    if (!stamp || !stamp[0]) {
	return 0;
    }

    db_result = get_apop_phrase(name, phrase, (int) sizeof(phrase));
    if (db_result <= 0) {
	return 0;
    }

    MD5Init(&context);
    MD5Update(&context, stamp, strlen(stamp));
    MD5Update(&context, phrase, strlen(phrase));
    MD5Final(digest, &context);

    for (i = 0; i < 16; i++) {
	phrase[2 * i] = hex[(digest[i] & 0xF0) >> 4];
	phrase[2 * i + 1] = hex[(digest[i] & 0x0F)];
    }
    phrase[32] = '\0';
    if (strcmp(hash, phrase)) {
	return 0;
    }
    return db_result;
}
