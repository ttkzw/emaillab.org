#ifndef CONF_APOP_H
#define CONF_APOP_H

/* owner of the apop database and setuid executable. */
#define APOP_USERNAME     "apopdb"

/* path to the apop database directory tree. */
#define APOP_DB_PATH      "/var/qmail/apopdb"

/* define CONF_MAILHOME _only_ if you have a centralized mail spool tree */
/* #define CONF_MAILHOME     "/var/mailhome" */
#define CONF_MAILHOME     "/home/pop"

/* owner of the password-less POP-only accounts */
#define POPBOX_USERNAME   "pop"

/* define POP_BEFORE_SMTP only if you need. */
/* #define POP_BEFORE_SMTP */

#endif
