#ifndef APOPAUTH_H
#define APOPAUTH_H

extern int apop_auth(/*char *loginname, char *passphrase, char *timestamp*/);
extern int plain_auth(/*char *loginname, char *password*/);
extern int has_apop(/*char *loginname*/);

#endif
