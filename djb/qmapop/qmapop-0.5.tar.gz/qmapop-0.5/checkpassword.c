/*
 * Derived from checkpassword 0.81, beta, 19981121, which was
 * written by D. J. Bernstein, djb@pobox.com.
 * Changes by Bert Gijsbers (bert@mc.bio.uva.nl) to support
 * the timestamp argument and APOP authentication.
 * Changes by TAKIZAWA Takashi (taki@cyber.email.ne.jp) to adapt to
 * checkpassword 0.81 and qmail 1.03 and to merge opensmtp.
 * All changes donated to D. J. Bernstein.
 */
#include <sys/types.h>
#include <sys/wait.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <pwd.h>
extern int errno;
extern char *malloc();
extern char **environ;
#include "apopauth.h"
#define PLAINAUTH "0"
#define APOPAUTH "1"

/* configuration file */
#include "conf-apop.h"
#include "conf-opensmtp.h"

int error_txtbsy =
#ifdef ETXTBSY
ETXTBSY;
#else
-4;
#endif

static struct passwd *pw;

void doit(login)
char *login;
{
  pw = getpwnam(login);
  if (! pw) {
    if (errno == error_txtbsy) _exit(111);
    _exit(1);
  }
}

char *str1e2(name,value)
char *name;
char *value;
{
  char *nv;
  nv = malloc(strlen(name) + strlen(value) + 2);
  if (!nv) _exit(111);
  strcpy(nv,name);
  strcat(nv,"=");
  strcat(nv,value);
  return nv;
}

char *str1e23(name,value0,value1,value2)
char *name;
char *value0;
char *value1;
char *value2;
{
  char *nv;
  nv = malloc(strlen(name) + strlen(value0) + strlen(value1) 
	      + strlen(value2) + 2);
  if (!nv) _exit(111);
  strcpy(nv,name);
  strcat(nv,"=");
  strcat(nv,value0);
  strcat(nv,value1);
  strcat(nv,value2);
  return nv;
}

static char up[512];
static int uplen;

void main(argc,argv)
int argc;
char **argv;
{
  char *login;
  char *password;
  char *timestamp;
  char *authtype;
  char *encrypted;
  int r;
  int i;
  int apop_result;
  char **newenv;
  int numenv;

  if (!argv[1]) _exit(2);

  uplen = 0;
  for (;;) {
    do
      r = read(3,up + uplen,sizeof(up) - uplen);
    while ((r == -1) && (errno == EINTR));
    if (r == -1) _exit(111);
    if (r == 0) break;
    uplen += r;
    if (uplen >= sizeof(up)) _exit(1);
  }

  close(3);

  i = 0;
  login = up + i;
  while (up[i++]) if (i == uplen) _exit(2);
  password = up + i;
  if (i == uplen) _exit(2);
  while (up[i++]) if (i == uplen) _exit(2);
  if (i == uplen) _exit(2);
  timestamp = up + i;
  while (up[i++]) if (i == uplen) _exit(2);
  if (i == uplen) _exit(2);
  authtype = up + i;
  while (up[i++]) if (i == uplen) _exit(2);
  
  if (login[0] == '/') _exit(1);
 
  if (strcmp(authtype,PLAINAUTH) == 0) {
    apop_result = plain_auth(login, password);
  } else if (strcmp(authtype,APOPAUTH) == 0){
    apop_result = apop_auth(login, password, timestamp);
  } else _exit(1);
  for (i = 0;password[i];++i) password[i] = 0;
  if (apop_result <= 0 || apop_result > 2) _exit(1);
  if (apop_result == 2) doit(POPBOX_USERNAME);
  else doit(login);
 
#ifdef OPENSMTP
  if (1) {
    int child;
    int wstat;
    char *opensmtp = OPENSMTP;
    
    switch(child = fork()) {
    case -1: _exit(111); break;
    case 0: execl(opensmtp, opensmtp, 0); _exit(111); break;
    }
    waitpid(child, &wstat, 0);
    if (!WIFEXITED(wstat)) _exit(111);
  }
#endif

  if (setgid(pw->pw_gid) == -1) _exit(1);
  if (setuid(pw->pw_uid) == -1) _exit(1);
#ifdef CONF_MAILHOME
  if (apop_result == 2) {
    if (chdir(CONF_MAILHOME) == -1) _exit(111);
    for (i = 0; login[i]; i++) {
      if (login[i] == '.') login[i] = ':';
      if (login[i] == '/') _exit(1);
    }
    if (chdir(login) == -1) _exit(111);
  } else 
    if (chdir(pw->pw_dir) == -1) _exit(111);
#else
  if (chdir(pw->pw_dir) == -1) _exit(111);
#endif
  
  /* set environ */
  numenv = 0;
  while (environ[numenv]) ++numenv;
  newenv = (char **) malloc((numenv + 4) * sizeof(char *));
  if (!newenv) _exit(111);
  for (i = 0;i < numenv;++i) newenv[i] = environ[i];
  if (apop_result == 2) {
    newenv[numenv++] = str1e2("USER",login);
    newenv[numenv++] = str1e23("HOME",pw->pw_dir,"/",login);
  } else {
    newenv[numenv++] = str1e2("USER",pw->pw_name);
    newenv[numenv++] = str1e2("HOME",pw->pw_dir);
  }
  newenv[numenv++] = str1e2("SHELL",pw->pw_shell);
  newenv[numenv] = 0;
  environ = newenv;

  execvp(argv[1],argv + 1);
  _exit(111);
}
