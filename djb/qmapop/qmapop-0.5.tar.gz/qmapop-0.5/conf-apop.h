#ifndef CONF_APOP_H
#define CONF_APOP_H

/* owner of the apop database and setuid executable. */
#define APOP_USERNAME     "apopdb"

/* path to the apop database directory tree. */
#define APOP_DB_PATH      "/var/qmail/apopdb"

/* owner of the password-less POP-only accounts */
#define POPBOX_USERNAME   "pop"

/* define CONF_MAILHOME _only_ if you have a centralized mail spool tree.
  This is the POPBOX_USERNAME's home directory */
#define CONF_MAILHOME     "/home/pop"

#endif
