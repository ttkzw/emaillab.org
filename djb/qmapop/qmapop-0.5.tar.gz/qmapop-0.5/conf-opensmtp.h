#ifndef CONF_OPENSMTP_H
#define CONF_OPENSMTP_H

/* define path of pop3-record only if you need POP before SMTP. */
/* #define OPENSMTP		"/usr/local/bin/pop3-record" */
#undef OPENSMTP

#endif
