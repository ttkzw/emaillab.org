/*

 $Id: ssmtp.c,v 2.48 2001/11/02 10:57:37 matt Exp $

 sSMTP -- send messages via SMTP to a mailhub for local delivery or forwarding.
 This program is used in place of /usr/sbin/sendmail, called by "mail" (et all).
 sSMTP does a selected subset of sendmail's standard tasks (including exactly
 one rewriting task), and explains if you ask it to do something it can't. It
 then sends the mail to the mailhub via an SMTP connection. Believe it or not,
 this is nothing but a filter

 See COPYRIGHT for the license

*/

#include <sys/param.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <pwd.h>

#include <syslog.h>
#include <signal.h>
#include <setjmp.h>
#include <string.h>
#include <ctype.h>

#include "ssmtp.h"

#ifndef MAILHUB
#define MAILHUB "mailhost"	/* A surprisingly useful default. */
#endif
char *ProgName = NULL;		/* It's name. */
char *MailHub = MAILHUB;	/* The place to send the mail. */
int smtp_port = 25;	        /* SMTP port number */
char HostName[MAXHOSTNAMELEN];	/* Our name, unless overridden. */
#ifdef REWRITE_DOMAIN
char *RewriteDomain = "localhost";	/* Place to claim to be. */
Bool UseRD = False;			/* Do we have to rewrite the domain? */
#endif
Bool from_override = False;		/* Should we use same address in the
				   from-line of the envelope as in the
				   From:-line? */
char *msg_from = NULL;		/* From:-line from message */
char *mail_from = NULL;		/* From:-line we actually use */
char *minus_f = NULL;		/* Content of the From: field if specified with the -f option */
char *minus_F = NULL;		/* Same for -F option */
char *full_name = NULL;		/* Sending user's full name */
char *Root = "postmaster";	/* Person to send root's mail to. */
jmp_buf TimeoutJmpBuf;		/* Timeout waiting for input from network. */
Bool minus_v = False;		/* Tell the user what's happening. */
Bool minus_t = False;		/* Was a T option given? */

char *RCPT_list[100];
char **rec = RCPT_list;
static Bool from_seen = False,
#ifdef HASTO_OPTION
to_seen = False,
#endif
date_seen = False;

#ifdef DEBUG
int log_level = 1;
#else
int log_level = 0;
#endif

char *authUsername = NULL;      /* user name for SMTP authentication */
char *authPassword = NULL;      /* password for SMTP authentication */

void *headerp;			/* Pointer to beginning of headers */

Bool UseTLS = False;		/* Use SSL to transfer mail to HUB */
Bool UseTLSCert = False;		/* Use a certificate to transfer SSL mail */
char *TLSCert = "/etc/ssl/certs/ssmtp.pem";	/* Default Certificate */ 

/* Current date in RFC format. */
#define ARPADATE_LENGTH 32
char date_str[ARPADATE_LENGTH];

/*
get_addr() -- parse user@domain,com from email address
*/
void get_addr(char *str, char *buf, size_t sz)
{
	char *p, *sd;
	size_t i;

	i = 0;
	if((p = strchr(str, '<'))) {
		p++;
		while(*p && (*p != '>') && (i < sz)) {
			buf[i++] = *p++;
		}
		buf[i] = (char)NULL;
	}
	else {
		p = str;
		while(*p && (i < sz)) {
			switch(*p) {
				case '\n':
				case '\t':
						buf[i] = ' ';

				case '(':
						while(*p && (*p != ')')) p++;
						p++;
						continue;
/*
				case '"':
						while(*p && (*p != '"')) p++;
						p++;
						continue;
*/
				default:
						buf[i] = *p++;
			}
			i++;
		}
		buf[i] = (char)NULL;

		/* Strip leading spaces */
		if((sd = strdup(buf)) == NULL) {
			die("strup() failed in get_addr()");
		}
		while(*sd && isspace(*sd)) sd++;

		if(strncpy(buf, sd, sz) == NULL) {
			die("strncpy() failed in get_addr()");
		}

		/* Strip trailing spaces */
		i = strlen(buf);
		while(i-- > 0) {
			if(isspace(buf[i]) == 0) break;
		}
		buf[(i + 1)] = (char)NULL;
	}
}

/*
RCPT_record() -- Record the email RCPT addresses
*/
void RCPT_record(char *str)
{
	char buf[(BUF_SZ + 1)], *p;
	Bool in_quotes = False;

	/* Convert <CR> and <TAB> to space */
	p = str;
	while(*p) {
		if((*p == '\n') || (*p == '\t')) {
			*p = ' ';
		}
		p++;
	}
	p = str;

	while(*p) {
		if(*p == '"') {
			if(in_quotes == False) {
				in_quotes = True;
			}
			else {
				in_quotes = False;
			}
		}

		if(((*p == ',') || (*(p + 1) == (char)NULL)) && (!in_quotes)) {
			if(*(p + 1) != (char)NULL) {
				*p = (char)NULL;
			}

			while(*str && isspace(*str)) str++;
			get_addr(str, buf, BUF_SZ);

			str = (p + 1);

			if(strlen(buf) > 0) {
				if((rec - RCPT_list) > (100 - 1)) {
					die("Too many recipients (>= 100)");
				}
			}

			if((*rec++ = strdup(buf)) == NULL) {
				die("strdup() failed in X()");
			}
		}
		p++;
	}
}

/*
record_headers() -- note which ones we've seen
*/
void record_headers(char *str)
{
	if(strncasecmp(str, "From:", 5) == 0) {
		from_seen = True;
	}
#ifdef HASTO_OPTION
	else if(strncasecmp(str, "To:" ,3) == 0) {
		to_seen = True;
	}
#endif
	else if(strncasecmp(str, "Date:", 5) == 0) {
		date_seen = True;
	}

	if(minus_t) {
		/* Need to figure out recipients from the e-mail */
		if(strncasecmp(str, "To:", 3) == 0) {
			RCPT_record((str + 4));
		}
		else if(strncasecmp(str, "Bcc:", 4) == 0) {
			RCPT_record((str + 5));
		}
		else if(strncasecmp(str, "CC:", 3) == 0) {
			RCPT_record((str + 4));
		}
	}
}

/*
append_domain() -- Fix up address with @domain.name
*/
char *append_domain(char *str)
{
#ifdef REWRITE_DOMAIN
	static char buf[(BUF_SZ + 1)];

	if(strchr(str, '@') == NULL) {
		if(snprintf(buf, BUF_SZ, "%s@%s", str,
			(UseRD == True) ? RewriteDomain : HostName) == -1) {
			die("Buffer error in append_domain()");
		}
		return(buf);
	}
#endif

	return(str);
}

/* 
strip_from() -- transforms "Name <login@host>" into "login@host" or "login@host (Real name)"
*/
char *strip_from(char *str)
{
	char buf[(BUF_SZ + 1)], *sd;

	if(strncmp("From: ", str, 6) == 0) {
		str += 6;
	}

	/* Remove the real name if necessary - just send the address */
	get_addr(str, buf, BUF_SZ);

	if((sd = strdup(buf)) == NULL) {
		die("strdup() failed in strip_from()");
	}
	return(sd);
}

#ifdef REWRITE_DOMAIN
/*
fix_from() -- replace whole From: header with standardised pattern
		Evil, nasty, immoral header-rewriting code (:-))
*/
void fix_from(char *buf, int sz)
{
	if(strncasecmp(buf, "From:", 5) == 0) {
		if(from_override) {
			if((msg_from = strdup(buf)) == NULL) {
				die("strdup() failed in fix_from()");
			}
		}
		else {
			if(snprintf(buf, sz, "From: %s", mail_from) == -1) {
				die("Buffer error in fix_from()");
			}
		}
	}
}
#endif

/*
RCPT_remap() -- alias systems-level users to the person who
	reads their mail.  This is variously the owner of a workstation,
	the sysadmin of a group of stations and the postmaster otherwise.
	We don't just mail stuff off to root on the mailhub (:-))
*/
char *RCPT_remap(char *str)
{
	struct passwd *pw;

	if(strchr(str, '@') ||
		((pw = getpwnam(str)) == NULL) || (pw->pw_uid > MAXSYSUID)) {
		/* It's not a local systems-level user */
		return(append_domain(str));
	}
	else {
		return(append_domain(Root));
	}
}

/*
do_from() -- generate a from line in standard format
 ("Real Name <id@site>" or "id@site") based on local user and host names
*/
void do_from(struct passwd *pw)
{
	char buf[(BUF_SZ + 1)];

	if(full_name) {
		if(snprintf(buf, BUF_SZ, "%s <%s@%s>", full_name, pw->pw_name,
#ifdef REWRITE_DOMAIN
			UseRD == True ? RewriteDomain : HostName
#else
			HostName
#endif
			) == -1) {
				die("Buffer error in do_from()");
		}
	}
	else {
		if(snprintf(buf, BUF_SZ, "%s@%s", pw->pw_name,
#ifdef REWRITE_DOMAIN
			UseRD == True ? RewriteDomain : HostName
#else
			HostName
#endif
			) == -1) {
				die("Buffer error in do_from()");
		}
	}

	if((mail_from = strdup(buf)) == NULL) {
		die("strdup() failed in X()");
	}
}

/*
handler() -- a ``normal'' non-portable version of an alarm handler
      Alas, setting a flag and returning is not fully functional in
      BSD: system calls don't fail when reading from a ``slow'' device
      like a socket. So we longjump instead, which is erronious on
      a small number of machines and ill-defined in the language
*/
void handler(void)
{
	extern jmp_buf TimeoutJmpBuf;

	longjmp(TimeoutJmpBuf, (int)1);
}

/*
standardise() -- trim off '\n's, double leading dots
*/
void standardise(char *str)
{
	size_t sl;
	char *p;

	if((p = strchr(str, '\n'))) {
		*p = (char)NULL;
	}

	/* Any line beginning with a dot has an additional dot inserted;
	not just a line consisting solely of a dot.  Thus we have to
	slide the buffer down one.  */
	sl = strlen(str);

	if(*str == '.') {
		if((sl + 2) > BUF_SZ) {
			die("Buffer overflow in standardise()");
		}
		(void)memmove((str + 1), str, (sl + 1));  /* Copy trailing \0 */

		*str = '.';
	}
}

/*
parse_config() -- parse config file, extract values of a few predefined variables
*/
void parse_config(FILE * fp)
{
	char buf[(BUF_SZ + 1)], *p, *q, *r;

	while(fgets(buf, sizeof(buf), fp)) {
		/* Make comments invisible. */
		if((p = strchr(buf, '#'))) {
			*p = (char)NULL;
		}

		/* Ignore malformed lines and comments. */
		if(strchr(buf, '=') == NULL) continue;

		/* Parse out keywords. */
		if(((p = strtok(buf, "= \t\n")) != NULL) && ((q = strtok(NULL, "= \t\n:")) != NULL)) {
			if(strcasecmp(p, "Root") == 0) {
				if((Root = strdup(q)) == NULL) {
					die("strdup() failed in parse_config()");
				}

				if(log_level > 0) {
					log_event(LOG_INFO, "Set Root=\"%s\"\n", Root);
				}
			}
			else if(strcasecmp(p, "MailHub") == 0) {
				if((MailHub = strdup(q)) == NULL) {
					die("strdup() failed in parse_config()");
				}

				if((r = strtok(NULL, "= \t\n:")) != NULL) {
					smtp_port = atoi(r);
				}

				if(log_level > 0) {
					log_event(LOG_INFO, "Set MailHub=\"%s\"\n", MailHub);
					log_event(LOG_INFO, "Set RemotePort=\"%d\"\n", smtp_port);
				}
			}
			else if(strcasecmp(p, "HostName") == 0) {
				if(strncpy(HostName, q, MAXHOSTNAMELEN) == NULL) {
					die("strncpy() failed in X()");
				}

				if(log_level > 0) {
					log_event(LOG_INFO, "Set HostName=\"%s\"\n", HostName);
				}
			}
#ifdef REWRITE_DOMAIN
			else if(strcasecmp(p, "RewriteDomain") == 0) {
				if((RewriteDomain = strdup(q)) == NULL) {
					die("strdup() failed in parse_config()");
				}

				UseRD = True;
				if(log_level > 0) {
					log_event(LOG_INFO, "Set RewriteDomain=\"%s\"\n", RewriteDomain);
				}
			}
#endif
			else if(strcasecmp(p, "FromLineOverride") == 0) {
				if(strcasecmp(q, "yes") == 0) {
					from_override = True;
				}
				else {
					from_override = False;
				}

				if(log_level > 0) {
					log_event(LOG_INFO, "Set FromLineOverride=\"%s\"\n", from_override ? "True" : "False");
				}
			}
			else if(strcasecmp(p, "RemotePort") == 0) {
				smtp_port = atoi(q);

				if(log_level > 0) {
					log_event(LOG_INFO, "Set RemotePort=\"%d\"\n", smtp_port);
				}
			}
#ifdef HAVE_SSL
			else if(strcasecmp(p, "UseTLS") == 0) {
				if(strcasecmp(q, "yes") == 0) {
					UseTLS = True;
				}
				else {
					UseTLS = False;
				}

				if(log_level > 0) { 
					log_event(LOG_INFO, "Set UseTLS=\"%s\"\n", UseTLS ? "True" : "False");
				}
			}
			else if(strcasecmp(p, "UseTLSCert") == 0) {
				if(strcasecmp(q, "yes") == 0) {
					UseTLSCert = True;
				}
				else {
					UseTLSCert = False;
				}

				if(log_level > 0) {
					log_event(LOG_INFO, "Set UseTLSCert=\"%s\"\n", UseTLSCert ? "True" : "False");
				}
			}
			else if(strcasecmp(p, "TLSCert") == 0) {
				if((TLSCert = strdup(q)) == NULL) {
					die("strdup() failed in parse_config()");
				}

				if(log_level > 0) {
					log_event(LOG_INFO, "Set TLSCert=\"%s\"\n", TLSCert);
				}
			}
#endif
			else {
				log_event(LOG_INFO, "Unable to set %s=\"%s\"\n", p, q);
			}
		}
	}

	return;
}

/*
* Config file access routines
*/
int read_config(void)
{
	FILE *fp;
	static char *locations[] =
		{
			CONFIGURATION_FILE,
			NULL
		};
	char **lp;

	for(lp = &locations[0]; *lp; lp++) {
		if((fp = fopen(*lp, "r")) != NULL) {
			parse_config(fp);
			fclose(fp);
			return(True);
		}
	}
	return(False);
}

/*
rev_aliases() -- parse the reverse alias file, fix globals to use any entry for sender
*/
void rev_aliases(struct passwd *pw)
{
	static char buffer[(BUF_SZ + 1)];
	char buf[(BUF_SZ + 1)], *p, *r;
	FILE *rev_file;

	/* Try to open the reverse aliases file */
	rev_file = fopen(REVALIASES_FILE, "r");
	/* Search if a reverse alias is definied for the sender */
	if(rev_file) {
		while(fgets(buf, sizeof(buf), rev_file)) {
			/* Make comments invisible. */
			if((p = strchr(buf, '#'))) {
				*p = (char)NULL;
			}

			/* Ignore malformed lines and comments. */
			if(strchr(buf, ':') == NULL) {
				continue;
			}

			/* Parse the alias */
			if(((p = strtok(buf, ":")) != NULL) && !strcmp(p, pw->pw_name)) {
				p = strtok(NULL, ": \t\r\n");
				if(p) {
					if(full_name) {
						(void)snprintf(buffer, BUF_SZ, "\"%s\" <%s>", full_name, p);
					}
					else {
						(void)snprintf(buffer, BUF_SZ, "%s", p);
					}

					if((mail_from = strdup(buffer)) == NULL) {
						die("strdup() failed in X()");
					}
				}
				p = strtok(NULL, " \t\r\n:");

				if(p) {
					MailHub = strdup(p);

					if((r = strtok(NULL, " \t\r\n:")) != NULL) {
						smtp_port = atoi(r);
					}

					if(log_level > 0) {
						log_event(LOG_INFO, "Set MailHub=\"%s\"\n", MailHub);
						log_event(LOG_INFO, "via SMTP Port Number=\"%d\"\n", smtp_port);
					}
				}
			}
		}
	}
}

/*
doOptions() -- pull the options out of the command-line, process them (and special-case calls to mailq, etc), and return the rest
*/
char **doOptions(int argc, char *argv[])
{
	static char Version[] = "$Revision: 2.48 $";
	static char *newArgV[MAXARGS];
	int i, j, add, newArgC;

	newArgV[0] = argv[0];
	newArgC = 1;

	if(strcmp(ProgName, "mailq") == 0) {
		/* Someone wants to know the queue state... */
		paq("mailq: Mail queue is empty\n");
	}
	else if(strcmp(ProgName, "newaliases") == 0) {
		/* Someone wanted to recompile aliases. */
		paq("newaliases: Aliases are not used in sSMTP\n");
	}

	i = 1;
	while(i < argc) {
		if(argv[i][0] != '-') {
			newArgV[newArgC++] = argv[i++];
			continue;
		}
		j = 0;

		add = 1;
		while(argv[i][++j] != (char)NULL) {
			switch(argv[i][j]) {
			case 'a':
				switch(argv[i][++j]) {
				case 'u':
					if(!argv[i][j+1]) { 
						authUsername = strdup(argv[i+1]);
						add++;
					}
					else {
						authUsername = strdup(argv[i]+j+1);
					}
					goto exit;

				case 'p':
					if(!argv[i][j+1]) { 
						authPassword = strdup(argv[i+1]);
						add++;
					}
					else {
						authPassword = strdup(argv[i]+j+1);
					}
					goto exit;
				}
				goto exit;

			case 'b':
				switch(argv[i][++j]) {

				case 'a':	/* ARPANET mode. */
						paq("-ba is not supported by sSMTP\n");
				case 'd':	/* Run as a daemon. */
						paq("-bd is not supported by sSMTP\n");
				case 'i':	/* Initialise aliases. */
						paq("%s: Aliases are not used in sSMTP\n", ProgName);
				case 'm':	/*  Default addr processing. */
						continue;
				case 'p':	/* Print mailqueue. */
						paq("%s: Mail queue is empty\n", ProgName);
				case 's':	/* Read SMTP from stdin. */
						paq("-bs is not supported by sSMTP\n");
				case 't':	/* Test mode. */
						paq("-bt is meaningless to sSMTP\n");
				case 'v':	/*  Verify names only. */
						paq("-bv is meaningless to sSMTP\n");
				case 'z':	/* Create  freeze file. */
						paq("-bz is meaningless to sSMTP\n");
				}

			case 'C':	/* Configfile name. */
					goto exit;
			case 'd':	/* Debug */
					log_level = 1;
					minus_v = True;	/* Almost the same thing... */
					continue;
			case 'E':	/* insecure channel, don't trust userid. */
					continue;
			case 'R':
				if(!argv[i][j+1]) {	/* amount of the message to be returned */
					add++;
					goto exit;
				}
				else {	/* Process queue for recipient */
					continue;
				}
			case 'F':	/* Fullname of sender */
				if(!argv[i][(j + 1)]) {
					minus_F = strdup(argv[(i + 1)]);
					add++;
				}
				else {
					minus_F = strdup(argv[i]+j+1);
				}
				goto exit;
			case 'f':	/* Set from/sender address. */
			case 'r':	/* Obsolete -f flag. */
				if(!argv[i][(j + 1)]) {
					if((minus_f = strdup(argv[(i + 1)])) == NULL) {
						die("strdup() failed in X()");
					}
					add++;
				}
				else {
					if((minus_f = strdup(argv[i]+j+1)) == NULL) {
						die("strdup failed in X()");
					}
				}

				if(strcpy(minus_f, strip_from(minus_f)) == NULL) {
					die("strcpy() failed in X()");
				}
				goto exit;
			case 'h':	/* Set hopcount. */
				continue;
			case 'm':	/* Ignore originator in adress list */
				continue;
			case 'M':	/* Use specified message-id */
				goto exit;
			case 'N':	/* dsn options */
				add++;
				goto exit;
			case 'n':	/* No aliasing */
				continue;
			case 'o':
				switch(argv[i][++j]) {

				case 'A':	/* Alternate aliases file. */
						goto exit;
				case 'c':	/* Delay connections. */
						continue;
				case 'D':	/* Run newaliases if rqd. */
						paq("%s: Aliases are not used in sSMTP\n", ProgName);
				case 'd':	/* Deliver now, in background or queue. */
						/* This may warrant a diagnostic for b or q. */
						continue;
				case 'e':	/* Errors: mail, write or none. */
						j++;
						continue;
				case 'F':	/* Set tempfile mode. */
						goto exit;
				case 'f':	/* Save ``From ' lines. */
						continue;
				case 'g':	/* Set group id. */
						goto exit;
				case 'H':	/* Helpfile name. */
						continue;
				case 'i':	/* DATA ends at EOF, not \n.\n */
						continue;
				case 'L':	/* Log level. */
						goto exit;
				case 'm':	/* Send to me if in the list. */
						continue;
				case 'o':	/* Old headers, spaces between adresses. */
						paq("-oo is not supported by sSMTP\n");
				case 'Q':	/* Queue dir. */
						goto exit;
				case 'r':	/* Read timeout. */
						goto exit;
				case 's':	/* Always init the queue. */
						continue;
				case 'S':	/* Stats file. */
						goto exit;
				case 'T':	/* Queue timeout. */
						goto exit;
				case 't':	/* Set timezone. */
						goto exit;
				case 'u':	/* Set uid. */
						goto exit;
				case 'v':	/* Set verbose flag. */
						minus_v = True;
						continue;
				}
				break;
			case 'q':	/* Process the queue [at time] */
					paq("%s: Mail queue is empty\n", ProgName);
			case 't':	/* Read message's To/Cc/Bcc lines. */
					minus_t = True;
					continue;
			case 'v':	/* minus_v (ditto -ov). */
					minus_v = True;
					break;
			case 'V':	/*  Say version and quit. */
					/* Similar as die, but no logging */
					paq("sSMTP %s (not sendmail at all)", Version);
			}
		}
		exit:
		i += add;
	}
	newArgV[newArgC] = NULL;

	if(newArgC <= 1 && !minus_t) {
		paq("%s: No recipients supplied, mail will not be sent\n", ProgName);
	}

	if(newArgC > 1 && minus_t)
		paq("%s: recipients with -t option not supported\n", ProgName);

	return(&newArgV[0]);
}

/*
ssmtp() -- send the message (exactly one) from stdin to the mailhub SMTP port
*/
int ssmtp(char *argv[])
{
	char buf[(BUF_SZ + 1)], *p, *q, *sd;
	size_t sl, hs, header_size = 0;
	struct passwd *pw;
	int i, sock;
	uid_t uid;

	uid = getuid();
	if((pw = getpwuid(uid)) == NULL) {
		die("Could not find password entry for sender (UID %d)", uid);
	}
	get_arpadate(date_str);

	if(read_config() == False) {
		log_event(LOG_INFO, "No ssmtp.conf in %s", SSMTPCONFDIR);
	}

	p = strtok(pw->pw_gecos, ";,");
	if(p) {
		full_name = strdup(p);
	}
	rev_aliases(pw);

	if(mail_from == NULL) {
		do_from(pw);
	}

	headerp = NULL;
	while(fgets(buf, BUF_SZ, stdin) != NULL) {
		if(*buf == '\n') break;

		sl = strlen(buf);
		hs = header_size;
		header_size += sl;
		headerp = realloc(headerp, header_size);
		(void)memcpy((headerp + hs), buf, sl);
	}
	headerp = realloc(headerp, (header_size + 1));

	p = (char *)headerp;
	p[header_size] = (char)NULL;

	q = buf;
	while(*p) {
		if(*p == '\n') {
			switch(*++p) {
				case ' ':
				case '\t':	continue;

				default:
						*q = (char)NULL;

					/* Trim off \n, double leading .'s */
						standardise(buf);

						record_headers(buf);

#ifdef REWRITE_DOMAIN
						fix_from(buf, BUF_SZ);
#endif
						q = buf;
			}
		}
		*q++ = *p++;
	}
	/* Finished header processing */

	if(minus_t) {
		/* Sorry no support for the exclusions on the command line */
		/*      argv=recipients;       */
		*rec++ = NULL;
	}

	/* Now to the delivery of the message */
	(void)signal(SIGALRM, (void(*)()) handler);	/* Catch SIGALRM */
	(void)alarm((unsigned) MAXWAIT);		/* Set initial timer */
	if(setjmp(TimeoutJmpBuf) != 0) {
		/* Then the timer has gone off and we bail out. */
		die("Connection lost in middle of processing");
	}

	if((sock = SMTP_open(MailHub, smtp_port)) == -1) {
		die("Cannot open %s:%d", MailHub, smtp_port);
	}
	else if(SMTP_OK(sock, buf) == False) {
		die("Didn't get initial OK message from SMTP server");
	}

	/* If user supplied username and password, then try ELHO */
	/* do not really know if this is required or not...      */
	if(authUsername) {
		SMTP_write(sock, "EHLO %s", HostName);
	}
	else {
		SMTP_write(sock, "HELO %s", HostName);
	}
	(void)alarm((unsigned) MEDWAIT);

	if(SMTP_OK(sock, buf) == False) die("%s (%s)", buf, HostName);

	/* Try to log in if username was supplied */
	if(authUsername) {
		memset(buf, 0, sizeof(buf));
		to64frombits(buf, authUsername, strlen(authUsername));
		SMTP_write(sock, "AUTH LOGIN %s", buf);

		(void)alarm((unsigned) MEDWAIT);
		if(SMTP_read(sock, buf) != 3) {
			die("Server didn't accept AUTH LOGIN (%s)", buf);
		}
		memset(buf, 0, sizeof(buf));

		to64frombits(buf, authPassword, strlen(authPassword));
		SMTP_write(sock, "%s", buf);
		(void)alarm((unsigned) MEDWAIT);

		if(SMTP_OK(sock, buf) == False) {
			die("Authorization failed (%s)", buf);
		}
	}

	/* Send "MAIL FROM:" line */
	if(msg_from && from_override) {
		(void)snprintf(buf, BUF_SZ,
			"MAIL FROM:<%s>", append_domain(strip_from(msg_from)));
	}
	else {
		(void)snprintf(buf, BUF_SZ, "MAIL FROM:<%s>", (minus_f != NULL) ? append_domain(minus_f) : strip_from(mail_from));
	}

	SMTP_write(sock, buf);
	(void)alarm((unsigned) MEDWAIT);

	if(SMTP_OK(sock, buf) == NO) die("%s", buf);

	/* Send all the To: adresses. */
	/* Either we're using the -t option, or we're using the arguments */
	if(minus_t) {
		if(*RCPT_list == (char)NULL) {
			die("No recipients specified although -t option used");
		}

		i = 0;
		do {
			sd = strdup(RCPT_remap(RCPT_list[i]));
			SMTP_write(sock, "RCPT TO:<%s>", sd);
			(void)alarm((unsigned)MEDWAIT);

			if(SMTP_OK(sock, buf) == NO) {
				die("RCPT TO:<%s> (%s)", sd, buf);
			}
		}
		while(RCPT_list[++i]);
	}
	else {
		for(i = 1; argv[i] != NULL; i++) {
			p = strtok(argv[i], ",");
			while(p) {
				/* RFC822 Address  -> "foo@bar" */
				get_addr(p, buf, BUF_SZ);

				sd = strdup(RCPT_remap(buf));
				SMTP_write(sock, "RCPT TO:<%s>", sd);
				(void)alarm((unsigned) MEDWAIT);

				if(SMTP_OK(sock, buf) == NO) {
					die("RCPT TO:<%s> (%s)", sd, buf);
				}
				p = strtok(NULL, ",");
			}
		}
	}

	/* Send DATA. */
	SMTP_write(sock, "DATA");
	(void)alarm((unsigned) MEDWAIT);

	if(SMTP_read(sock, buf) != 3) {
		/* Oops, we were expecting "354 send your data" */
		die("%s", buf);
	}

	SMTP_write(sock, "Received: by %s (sSMTP sendmail emulation); %s",
		HostName, date_str);

	if(from_seen == False) {
		/* No From: line; add the sender specified in the command line or generate one */
		if(minus_F == NULL) {
			SMTP_write(sock, "From: %s", (minus_f == NULL) ? mail_from : minus_f);
		}
		else {
			SMTP_write(sock, "From: %s <%s>", minus_F, (minus_f == NULL) ? strip_from(mail_from) : minus_f);
		}
	}

	if(date_seen == False) {
		SMTP_write(sock, "Date: %s", date_str);
	}

#ifdef HASTO_OPTION
	if(to_seen == False) {
		SMTP_write(sock, "To: postmaster");
	}
#endif

	p = (char *)headerp;
	while(*p) {
		i = 0;
		while(*p && (*p != '\n') && (i < BUF_SZ)) {
			buf[i++] = *p++;
		}
		buf[i] = (char)NULL;

		if(*p) p++;

		SMTP_write(sock, "%s", buf);
	}
	free(headerp);
	(void)alarm((unsigned) MEDWAIT);

	/* End of headers, start body. */
	SMTP_write(sock, "");

	while(fgets(buf, sizeof(buf), stdin) != NULL) {
		/* Trim off \n, double leading .'s */
		standardise(buf);

		SMTP_write(sock, "%s", buf);
		(void)alarm((unsigned) MEDWAIT);
	}
	/* End of body. */

	SMTP_write(sock, ".");
	(void)alarm((unsigned) MAXWAIT);

	if(SMTP_OK(sock, buf) == NO) die("%s", buf);

	/* Close conection. */
	(void)signal(SIGALRM, SIG_IGN);
	SMTP_write(sock, "QUIT");
	(void)SMTP_OK(sock, buf);
	(void)close(sock);

	log_event(LOG_INFO,
		"Sent mail for %s (%s)", strip_from(mail_from), buf);

	return(0);
}

char *basename(char *path)
{
	static char buf[MAXPATHLEN +1];
	char *ptr;

	ptr = strrchr(path, '/');
	if(ptr) {
		if(strncpy(buf, ++ptr, MAXPATHLEN) == NULL) {
			die("strncpy() failed in basename()");
		}
	}
	else {
		if(strncpy(buf, path, MAXPATHLEN) == NULL) {
			die("strncpy() failed in basename()");
		}
	}
	buf[MAXPATHLEN] = (char)NULL;

	return(buf);
}

/*
main() -- make the program behave like sendmail, then call ssmtp
*/
int main(int argc, char **argv)
{
	char **newArgv;

	/* Try to be bulletproof :-) */
	(void)signal(SIGHUP, SIG_IGN);
	(void)signal(SIGINT, SIG_IGN);
	(void)signal(SIGTTIN, SIG_IGN);
	(void)signal(SIGTTOU, SIG_IGN);

	/* Set the globals. */
	ProgName = basename(argv[0]);

	if(gethostname(HostName, sizeof(HostName)) == -1) {
		die("Cannot get the name of this machine");
	}
	newArgv = doOptions(argc, argv);

	exit(ssmtp(newArgv));
}
