/*

 $Id: ssmtp.h,v 2.2 2001/10/15 18:41:51 matt Exp $

 See COPYRIGHT for the license

*/

#define YES 1
#define NO 0
typedef enum {False, True} Bool;

#define BUF_SZ  (1024 * 2)	/* A pretty large buffer, but not outrageous */

#define MAXWAIT (10 * 60)	/* Maximum wait between commands, in seconds */
#define MEDWAIT (5 * 60)

#define MAXSYSUID 999		/* Highest UID which is a system account */

#ifndef _POSIX_ARG_MAX
#define MAXARGS 4096
#else
#define MAXARGS  _POSIX_ARG_MAX
#endif

/*
logging.c
*/
void log_event(int, char *, ...);
void paq(char *, ...);
void die(char *, ...);

/*
netfunc.c
*/
int SMTP_read(int, char *);
void SMTP_write(int, char *, ...);
int SMTP_open(char *, int);
int SMTP_OK(int, char *);

/*
arpadate.c
*/
int get_arpadate(char *);

/*
base64.c
*/
void to64frombits(unsigned char *, const unsigned char *, int);
