echo 'Distribution of ddelays for successful deliveries

Meaning of each line: The first pct% of successful deliveries
all happened within doneby seconds. The average ddelay was avg.
'
( echo doneby avg pct
HOME/bin/ddist ) | HOME/bin/columnt
