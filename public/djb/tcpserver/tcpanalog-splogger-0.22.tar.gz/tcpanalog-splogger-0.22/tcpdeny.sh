#!/bin/sh
#  tcpanalog:tcpdeny
AWK '
  /^d/ {
    from = $6
    inet[from] = $2
    connect[from] += 1
    host[from] = $7
  }
  END {
    for (from in connect) {
      sub(":.*","",host[from])
      if (host[from] == "") {host[from] = "unknown"}
      print inet[from],connect[from],from,host[from]
    }
  }
'
