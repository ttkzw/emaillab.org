#!/bin/sh
#  tcpanalog:ztcpdeny
echo "tcpserver:refused connection"
(echo "service times ip-address hostname"
BIN/tcpdeny | sort) | BIN/column

