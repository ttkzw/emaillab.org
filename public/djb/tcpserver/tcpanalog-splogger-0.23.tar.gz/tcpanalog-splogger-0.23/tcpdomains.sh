#!/bin/sh
#  tcpanalog:tcpdomains
AWK '
  /^k/ {
    from = $7
    sub(":.*","",from)
    if( from != "") sub("[^.]*\.","",from) 
    else { from = "unknown"}
    tagfrom = $2.from
    domain[tagfrom] = from
    tag[tagfrom] = $2
    connect[tagfrom] += 1
    alive = ($5 - $4)
    total[tagfrom] += alive
    if ( alive > max[tagfrom]) { max[tagfrom] = alive}
  }
  END {
    for (tagfrom in connect) {
      rate = total[tagfrom]/connect[tagfrom]
      print tag[tagfrom],connect[tagfrom],sprintf("%.2f %.2f %.2f",total[tagfrom],max[tagfrom],rate),domain[tagfrom]
    }
  }
'
