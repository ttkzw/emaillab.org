#!/bin/sh
#  tcpanalog:tcphosts
AWK '
  /^k/ {
    tagfrom = $6.$2
    from[tagfrom] = $6
    tag[tagfrom] = $2
    connect[tagfrom] += 1
    alive = ($5 - $4)
    total[tagfrom] += alive
    if ( alive > max[tagfrom]) max[tagfrom] = alive
    host[tagfrom] = $7
  }
  END {
    for (tagfrom in connect) {
      sub(":.*","",host[tagfrom])
      if (host[tagfrom] == "") {host[tagfrom] = "unknown"}
      rate = total[tagfrom]/connect[tagfrom]
      print tag[tagfrom],connect[tagfrom],sprintf("%.2f %.2f %.2f",total[tagfrom],max[tagfrom],rate),from[tagfrom],host[tagfrom]
    }
  }
'
