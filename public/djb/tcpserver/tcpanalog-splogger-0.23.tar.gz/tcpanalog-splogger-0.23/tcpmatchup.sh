#!/bin/sh
#  tcpanalog:tcpmatchup
#
#  pid: pid number
#  tag[m]: tag of syslog
#  dreq[m]: date when connection is requested
#  from[m]: "from" host
#  dstart[m]: starting date of connection
#  dend[m]: ending date of connection
#  result[m]: result
#             ok:"k"
#             deny:"d"
#  source[m]: source host
#  dest[m]: destination host
#  status[m]: status

AWK '
  {
    if ($4 == "pid"){
      pid = $5
      tag[pid] = $1
      sub(":","",tag[pid])
      dreq[pid] = $2
      from[pid] = $7

      dstart[pid] = $2
      dend[pid] = $2
      result[pid] = "?"
      source[pid] = "?"
      dest[pid] = "?"
      status[pid] = "?"
    }
    if ($4 == "ok"){
      pid = $5
      result[pid] = "k"
      dstart[pid] = $2
      source[pid] = $7
      dest[pid] = $6
    }
    if ($4 == "deny"){
      pid = $5
      result[pid] = "d"
      dstart[pid] = $2
      source[pid] = $7
      dest[pid] = $6
    }
    if ($4 == "end"){
      pid = $5
      dend[pid] = $2
      status[pid] = $7

      if (pid in dreq){
        print result[pid],tag[pid],dreq[pid],dstart[pid],dend[pid],from[pid],source[pid],dest[pid],status[pid]
        delete result[pid]
        delete tag[pid]
        delete dreq[pid]
        delete dstart[pid]
        delete dend[pid]
        delete from[pid]
        delete source[pid]
        delete dest[pid]
        delete status[pid]
      }
    }
  }
'
